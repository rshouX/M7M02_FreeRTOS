/******************************************************************************
Filename    : rmp_test.h
Author      : The RVM project generator.
Date        : 05/09/2024 21:43:11
License     : Unlicense; see COPYING for details.
Description : The RMP test header.
******************************************************************************/

/* Include *******************************************************************/
#include "Test/Chip/rmp_test_stm32l071cb_rvm.h"
/* End Include ***************************************************************/

/* End Of File ***************************************************************/

/* Copyright (C) Evo-Devo Instrum. All rights reserved ***********************/

