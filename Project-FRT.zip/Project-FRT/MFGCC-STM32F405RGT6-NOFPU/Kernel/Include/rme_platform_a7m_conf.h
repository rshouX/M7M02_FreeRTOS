/******************************************************************************
Filename    : rme_platform_a7m_conf.h
Author      : The RVM project generator.
Date        : 05/09/2024 21:42:56
License     : Unlicense; see COPYING for details.
Description : The chip selection header.
******************************************************************************/

/* Platform Include **********************************************************/
#include "rme_platform_stm32f405rg.h"
/* End Platform Include ******************************************************/

/* End Of File ***************************************************************/

/* Copyright (C) Evo-Devo Instrum. All rights reserved ***********************/

