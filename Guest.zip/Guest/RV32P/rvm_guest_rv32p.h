/******************************************************************************
Filename    : rvm_guest_rv32p.h
Author      : pry
Date        : 01/04/2017
Licence     : The Unlicense; see LICENSE for details.
Description : The header of platform-specific part of RMP for RVM.
******************************************************************************/

/* Typedef *******************************************************************/
#ifndef __RVM_GUEST_RV32P__
#define __RVM_GUEST_RV32P__

#ifndef __RVM_S32_T__
#define __RVM_S32_T__
typedef signed int rvm_s32_t;
#endif

#ifndef __RVM_S16_T__
#define __RVM_S16_T__
typedef signed short rvm_s16_t;
#endif

#ifndef __RVM_S8_T__
#define __RVM_S8_T__
typedef signed char rvm_s8_t;
#endif

#ifndef __RVM_U32_T__
#define __RVM_U32_T__
typedef unsigned int rvm_u32_t;
#endif

#ifndef __RVM_U16_T__
#define __RVM_U16_T__
typedef unsigned short rvm_u16_t;
#endif

#ifndef __RVM_U8_T__
#define __RVM_U8_T__
typedef unsigned char rvm_u8_t;
#endif

#ifndef __RVM_CID_T__
#define __RVM_CID_T__
/* Capability ID */
typedef rvm_s32_t rvm_cid_t;
#endif

#ifndef __RVM_TID_T__
#define __RVM_TID_T__
/* Thread ID */
typedef rvm_s32_t rvm_tid_t;
#endif

#ifndef __RVM_PTR_T__
#define __RVM_PTR_T__
/* Pointer */
typedef rvm_u32_t rvm_ptr_t;
#endif

#ifndef __RVM_CNT_T__
#define __RVM_CNT_T__
/* Counter */
typedef rvm_s32_t rvm_cnt_t;
#endif

#ifndef __RVM_RET_T__
#define __RVM_RET_T__
/* Return value */
typedef rvm_s32_t rvm_ret_t;
#endif
/* End Typedef ***************************************************************/

/* Define ********************************************************************/
/* System Macro **************************************************************/
/* Compiler "extern" keyword setting */
#define RVM_EXTERN                                  extern
/* The order of bits in one CPU machine word */
#define RVM_WORD_ORDER                              (5U)

/* Thread size */
#define RVM_HYP_RAW_SIZE                            ((21U)*RVM_WORD_BYTE)
/* Invocation size */
#define RVM_INV_RAW_SIZE                            ((9U)*RVM_WORD_BYTE)
/* Normal page directory size */
#define RVM_PGT_RAW_PTR(NMORD)                      (RVM_POW2(NMORD)*RVM_WORD_BYTE)
#define RVM_PGT_RAW_PERM(NMORD)                     RVM_ROUND_UP(RVM_POW2(NMORD),RVM_WORD_ORDER-3U)
#define RVM_PGT_RAW_REG(NMORD)                      (RVM_PGT_RAW_PTR(NMORD)+RVM_PGT_RAW_PERM(NMORD))
#define RVM_PGT_RAW_SIZE_NOM(NMORD)                 (2U*RVM_WORD_BYTE+RVM_PGT_RAW_REG(NMORD))
/* Top-level page directory size */
#define RVM_PGT_RAW_CFG                             RVM_ROUND_UP(RVM_RV32P_REGION_NUM,RVM_WORD_ORDER-3U)
#define RVM_PGT_RAW_DATA                            ((RVM_RV32P_REGION_NUM)*RVM_WORD_BYTE)           
#define RVM_PGT_RAW_SIZE_TOP(NMORD)                 (RVM_WORD_BYTE+RVM_PGT_RAW_CFG+RVM_PGT_RAW_DATA+RVM_PGT_RAW_SIZE_NOM(NMORD))
/* End System Macro **********************************************************/

/* RV32P Macro ***************************************************************/
/* Thread context attribute definitions - keep in accordance with kernel */
#define RVM_RV32P_ATTR_NONE                         (0U)
#define RVM_RV32P_ATTR_RVF                          RVM_POW2(0U)
#define RVM_RV32P_ATTR_RVD                          RVM_POW2(1U)

/* Page table entry mode which property to get */
#define RVM_RV32P_KFN_PGT_ENTRY_MOD_FLAG_GET        (0U)
#define RVM_RV32P_KFN_PGT_ENTRY_MOD_SZORD_GET       (1U)
#define RVM_RV32P_KFN_PGT_ENTRY_MOD_NMORD_GET       (2U)
/* Interrupt source configuration */
#define RVM_RV32P_KFN_INT_LOCAL_MOD_STATE_GET       (0U)
#define RVM_RV32P_KFN_INT_LOCAL_MOD_STATE_SET       (1U)
#define RVM_RV32P_KFN_INT_LOCAL_MOD_PRIO_GET        (2U)
#define RVM_RV32P_KFN_INT_LOCAL_MOD_PRIO_SET        (3U)
/* Prefetcher modification */
#define RVM_RV32P_KFN_PRFTH_MOD_STATE_GET           (0U)
#define RVM_RV32P_KFN_PRFTH_MOD_STATE_SET           (1U)
/* Prefetcher state */
#define RVM_RV32P_KFN_PRFTH_STATE_DISABLE           (0U)
#define RVM_RV32P_KFN_PRFTH_STATE_ENABLE            (1U)

/* Register read/write */
#define RVM_RV32P_KFN_DEBUG_REG_MOD_GET             (0U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_SET             RVM_POW2(16U)
/* General-purpose registers */
#define RVM_RV32P_KFN_DEBUG_REG_MOD_MSTATUS         (0U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_PC              (1U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X1_RA           (2U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X2_SP           (3U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X3_GP           (4U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X4_TP           (5U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X5_T0           (6U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X6_T1           (7U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X7_T2           (8U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X8_S0_FP        (9U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X9_S1           (10U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X10_A0          (11U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X11_A1          (12U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X12_A2          (13U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X13_A3          (14U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X14_A4          (15U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X15_A5          (16U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X16_A6          (17U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X17_A7          (18U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X18_S2          (19U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X19_S3          (20U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X20_S4          (21U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X21_S5          (22U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X22_S6          (23U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X23_S7          (24U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X24_S8          (25U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X25_S9          (26U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X26_S10         (27U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X27_S11         (28U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X28_T3          (29U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X29_T4          (30U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X30_T5          (31U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X31_T6          (32U)
/* FCSR & FPU registers */
#define RVM_RV32P_KFN_DEBUG_REG_MOD_FCSR            (33U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F0              (34U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F1              (35U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F2              (36U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F3              (37U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F4              (38U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F5              (39U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F6              (40U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F7              (41U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F8              (42U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F9              (43U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F10             (44U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F11             (45U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F12             (46U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F13             (47U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F14             (48U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F15             (49U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F16             (50U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F17             (51U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F18             (52U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F19             (53U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F20             (54U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F21             (55U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F22             (56U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F23             (57U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F24             (58U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F25             (59U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F26             (60U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F27             (61U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F28             (62U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F29             (63U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F30             (64U)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F31             (65U)
/* Getters */
#define RVM_RV32P_KFN_DEBUG_REG_MOD_MSTATUS_GET     (RVM_RV32P_KFN_DEBUG_REG_MOD_MSTATUS)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_PC_GET          (RVM_RV32P_KFN_DEBUG_REG_MOD_PC)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X1_RA_GET       (RVM_RV32P_KFN_DEBUG_REG_MOD_X1_RA)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X2_SP_GET       (RVM_RV32P_KFN_DEBUG_REG_MOD_X2_SP)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X3_GP_GET       (RVM_RV32P_KFN_DEBUG_REG_MOD_X3_GP)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X4_TP_GET       (RVM_RV32P_KFN_DEBUG_REG_MOD_X4_TP)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X5_T0_GET       (RVM_RV32P_KFN_DEBUG_REG_MOD_X5_T0)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X6_T1_GET       (RVM_RV32P_KFN_DEBUG_REG_MOD_X6_T1)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X7_T2_GET       (RVM_RV32P_KFN_DEBUG_REG_MOD_X7_T2)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X8_S0_FP_GET    (RVM_RV32P_KFN_DEBUG_REG_MOD_X8_S0_FP)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X9_S1_GET       (RVM_RV32P_KFN_DEBUG_REG_MOD_X9_S1)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X10_A0_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X10_A0)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X11_A1_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X11_A1)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X12_A2_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X12_A2)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X13_A3_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X13_A3)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X14_A4_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X14_A4)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X15_A5_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X15_A5)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X16_A6_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X16_A6)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X17_A7_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X17_A7)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X18_S2_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X18_S2)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X19_S3_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X19_S3)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X20_S4_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X20_S4)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X21_S5_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X21_S5)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X22_S6_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X22_S6)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X23_S7_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X23_S7)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X24_S8_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X24_S8)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X25_S9_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X25_S9)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X26_S10_GET     (RVM_RV32P_KFN_DEBUG_REG_MOD_X26_S10)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X27_S11_GET     (RVM_RV32P_KFN_DEBUG_REG_MOD_X27_S11)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X28_T3_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X28_T3)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X29_T4_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X29_T4)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X30_T5_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X30_T5)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X31_T6_GET      (RVM_RV32P_KFN_DEBUG_REG_MOD_X31_T6)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_FCSR_GET        (RVM_RV32P_KFN_DEBUG_REG_MOD_FCSR)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F0_GET          (RVM_RV32P_KFN_DEBUG_REG_MOD_F0)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F1_GET          (RVM_RV32P_KFN_DEBUG_REG_MOD_F1)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F2_GET          (RVM_RV32P_KFN_DEBUG_REG_MOD_F2)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F3_GET          (RVM_RV32P_KFN_DEBUG_REG_MOD_F3)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F4_GET          (RVM_RV32P_KFN_DEBUG_REG_MOD_F4)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F5_GET          (RVM_RV32P_KFN_DEBUG_REG_MOD_F5)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F6_GET          (RVM_RV32P_KFN_DEBUG_REG_MOD_F6)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F7_GET          (RVM_RV32P_KFN_DEBUG_REG_MOD_F7)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F8_GET          (RVM_RV32P_KFN_DEBUG_REG_MOD_F8)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F9_GET          (RVM_RV32P_KFN_DEBUG_REG_MOD_F9)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F10_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F10)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F11_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F11)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F12_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F12)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F13_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F13)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F14_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F14)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F15_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F15)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F16_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F16)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F17_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F17)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F18_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F18)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F19_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F19)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F20_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F20)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F21_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F21)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F22_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F22)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F23_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F23)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F24_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F24)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F25_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F25)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F26_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F26)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F27_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F27)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F28_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F28)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F29_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F29)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F30_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F30)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F31_GET         (RVM_RV32P_KFN_DEBUG_REG_MOD_F31)
/* Setters */
#define RVM_RV32P_KFN_DEBUG_REG_MOD_MSTATUS_SET     (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_MSTATUS)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_PC_SET          (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_PC)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X1_RA_SET       (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X1_RA)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X2_SP_SET       (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X2_SP)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X3_GP_SET       (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X3_GP)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X4_TP_SET       (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X4_TP)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X5_T0_SET       (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X5_T0)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X6_T1_SET       (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X6_T1)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X7_T2_SET       (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X7_T2)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X8_S0_FP_SET    (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X8_S0_FP)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X9_S1_SET       (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X9_S1)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X10_A0_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X10_A0)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X11_A1_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X11_A1)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X12_A2_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X12_A2)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X13_A3_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X13_A3)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X14_A4_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X14_A4)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X15_A5_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X15_A5)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X16_A6_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X16_A6)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X17_A7_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X17_A7)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X18_S2_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X18_S2)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X19_S3_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X19_S3)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X20_S4_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X20_S4)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X21_S5_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X21_S5)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X22_S6_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X22_S6)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X23_S7_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X23_S7)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X24_S8_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X24_S8)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X25_S9_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X25_S9)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X26_S10_SET     (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X26_S10)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X27_S11_SET     (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X27_S11)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X28_T3_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X28_T3)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X29_T4_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X29_T4)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X30_T5_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X30_T5)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_X31_T6_SET      (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_X31_T6)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_FCSR_SET        (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_FCSR)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F0_SET          (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F0)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F1_SET          (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F1)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F2_SET          (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F2)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F3_SET          (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F3)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F4_SET          (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F4)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F5_SET          (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F5)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F6_SET          (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F6)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F7_SET          (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F7)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F8_SET          (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F8)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F9_SET          (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F9)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F10_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F10)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F11_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F11)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F12_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F12)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F13_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F13)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F14_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F14)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F15_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F15)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F16_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F16)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F17_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F17)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F18_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F18)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F19_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F19)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F20_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F20)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F21_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F21)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F22_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F22)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F23_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F23)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F24_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F24)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F25_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F25)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F26_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F26)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F27_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F27)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F28_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F28)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F29_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F29)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F30_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F30)
#define RVM_RV32P_KFN_DEBUG_REG_MOD_F31_SET         (RVM_RV32P_KFN_DEBUG_REG_MOD_SET|RVM_RV32P_KFN_DEBUG_REG_MOD_F31)

/* Invocation register read/write */
#define RVM_RV32P_KFN_DEBUG_INV_MOD_SP_GET          (0U)
#define RVM_RV32P_KFN_DEBUG_INV_MOD_SP_SET          (1U)
#define RVM_RV32P_KFN_DEBUG_INV_MOD_PC_GET          (2U)
#define RVM_RV32P_KFN_DEBUG_INV_MOD_PC_SET          (3U)

/* Exception register read */
#define RVM_RV32P_KFN_DEBUG_EXC_CAUSE_GET           (0U)
#define RVM_RV32P_KFN_DEBUG_EXC_ADDR_GET            (1U)
#define RVM_RV32P_KFN_DEBUG_EXC_VALUE_GET           (2U)
/* End RV32P Macro ***********************************************************/
/* End Define ****************************************************************/

/* Struct ********************************************************************/
/* The register set struct */
struct RVM_Reg_Struct
{
    rvm_ptr_t MSTATUS;
    rvm_ptr_t PC;
    rvm_ptr_t X1_RA;
    rvm_ptr_t X2_SP;
    rvm_ptr_t X3_GP;
    rvm_ptr_t X4_TP;
    rvm_ptr_t X5_T0;
    rvm_ptr_t X6_T1;
    rvm_ptr_t X7_T2;
    rvm_ptr_t X8_S0_FP;
    rvm_ptr_t X9_S1;
    rvm_ptr_t X10_A0;
    rvm_ptr_t X11_A1;
    rvm_ptr_t X12_A2;
    rvm_ptr_t X13_A3;
    rvm_ptr_t X14_A4;
    rvm_ptr_t X15_A5;
    rvm_ptr_t X16_A6;
    rvm_ptr_t X17_A7;
    rvm_ptr_t X18_S2;
    rvm_ptr_t X19_S3;
    rvm_ptr_t X20_S4;
    rvm_ptr_t X21_S5;
    rvm_ptr_t X22_S6;
    rvm_ptr_t X23_S7;
    rvm_ptr_t X24_S8;
    rvm_ptr_t X25_S9;
    rvm_ptr_t X26_S10;
    rvm_ptr_t X27_S11;
    rvm_ptr_t X28_T3;
    rvm_ptr_t X29_T4;
    rvm_ptr_t X30_T5;
    rvm_ptr_t X31_T6;
};

/* Single-precision register set */
struct RVM_RV32P_RVF_Struct
{
    rvm_ptr_t FCSR;
    rvm_ptr_t F0;
    rvm_ptr_t F1;
    rvm_ptr_t F2;
    rvm_ptr_t F3;
    rvm_ptr_t F4;
    rvm_ptr_t F5;
    rvm_ptr_t F6;
    rvm_ptr_t F7;
    rvm_ptr_t F8;
    rvm_ptr_t F9;
    rvm_ptr_t F10;
    rvm_ptr_t F11;
    rvm_ptr_t F12;
    rvm_ptr_t F13;
    rvm_ptr_t F14;
    rvm_ptr_t F15;
    rvm_ptr_t F16;
    rvm_ptr_t F17;
    rvm_ptr_t F18;
    rvm_ptr_t F19;
    rvm_ptr_t F20;
    rvm_ptr_t F21;
    rvm_ptr_t F22;
    rvm_ptr_t F23;
    rvm_ptr_t F24;
    rvm_ptr_t F25;
    rvm_ptr_t F26;
    rvm_ptr_t F27;
    rvm_ptr_t F28;
    rvm_ptr_t F29;
    rvm_ptr_t F30;
    rvm_ptr_t F31;
};

/* Double-precision register set */
struct RVM_RV32P_RVFD_Struct
{
    rvm_ptr_t FCSR;
    rvm_ptr_t F0[2];
    rvm_ptr_t F1[2];
    rvm_ptr_t F2[2];
    rvm_ptr_t F3[2];
    rvm_ptr_t F4[2];
    rvm_ptr_t F5[2];
    rvm_ptr_t F6[2];
    rvm_ptr_t F7[2];
    rvm_ptr_t F8[2];
    rvm_ptr_t F9[2];
    rvm_ptr_t F10[2];
    rvm_ptr_t F11[2];
    rvm_ptr_t F12[2];
    rvm_ptr_t F13[2];
    rvm_ptr_t F14[2];
    rvm_ptr_t F15[2];
    rvm_ptr_t F16[2];
    rvm_ptr_t F17[2];
    rvm_ptr_t F18[2];
    rvm_ptr_t F19[2];
    rvm_ptr_t F20[2];
    rvm_ptr_t F21[2];
    rvm_ptr_t F22[2];
    rvm_ptr_t F23[2];
    rvm_ptr_t F24[2];
    rvm_ptr_t F25[2];
    rvm_ptr_t F26[2];
    rvm_ptr_t F27[2];
    rvm_ptr_t F28[2];
    rvm_ptr_t F29[2];
    rvm_ptr_t F30[2];
    rvm_ptr_t F31[2];
};

struct RVM_Exc_Struct
{
    rvm_ptr_t Cause;
    rvm_ptr_t Addr;
    rvm_ptr_t Value;
};
/* End Struct ****************************************************************/

/* Private Function **********************************************************/
#ifdef __HDR_PRIVATE__
#undef RVM_EXTERN
#define RVM_EXTERN
/*****************************************************************************/

/*****************************************************************************/
#endif
/* End Private Function ******************************************************/

/* Public Variable ***********************************************************/
/*****************************************************************************/

/*****************************************************************************/
/* End Public Variable *******************************************************/

/* Public Function ***********************************************************/
/*****************************************************************************/
/* Assembly veneer */
RVM_EXTERN void _RVM_Entry(void);
RVM_EXTERN void _RVM_Stub(void);

/* System call */
RVM_EXTERN rvm_ret_t RVM_Svc(rvm_ptr_t Op_Capid,
                             rvm_ptr_t Arg1,
                             rvm_ptr_t Arg2,
                             rvm_ptr_t Arg3);
RVM_EXTERN rvm_ret_t RVM_RV32P_Svc_Kfn(rvm_ptr_t Op_Capid,
                                       rvm_ptr_t ID,
                                       rvm_ptr_t* Param);
/* Invocation */
RVM_EXTERN rvm_ret_t RVM_Inv_Act(rvm_cid_t Cap_Inv,
                                 rvm_ptr_t Param,
                                 rvm_ptr_t* Retval);
RVM_EXTERN rvm_ret_t RVM_Inv_Ret(rvm_ptr_t Retval);

/* Utility */
RVM_EXTERN void RVM_Putchar(char Char);
RVM_EXTERN rvm_ptr_t RVM_Thd_Cop_Size(rvm_ptr_t Attr);

/* Kernel function */
RVM_EXTERN rvm_ret_t RVM_RV32P_Kfn_Act(rvm_cid_t Cap_Kfn,
                                       rvm_ptr_t Func_ID,
                                       rvm_ptr_t Sub_ID,
                                       rvm_ptr_t* Param);
RVM_EXTERN rvm_ret_t RVM_RV32P_Pgt_Entry_Mod(rvm_cid_t Cap_Kfn,
                                             rvm_cid_t Cap_Pgt,
                                             rvm_ptr_t Vaddr,
                                             rvm_ptr_t Type);
RVM_EXTERN rvm_ret_t RVM_RV32P_Int_Local_Mod(rvm_cid_t Cap_Kfn,
                                             rvm_ptr_t Int_Num,
                                             rvm_ptr_t Operation,
                                             rvm_ptr_t Param);
RVM_EXTERN rvm_ret_t RVM_RV32P_Int_Local_Trig(rvm_cid_t Cap_Kfn,
                                              rvm_ptr_t Int_Num);
RVM_EXTERN rvm_ret_t RVM_RV32P_Cache_Mod(rvm_cid_t Cap_Kfn,
                                         rvm_ptr_t Cache_ID,
                                         rvm_ptr_t Operation,
                                         rvm_ptr_t Param);
RVM_EXTERN rvm_ret_t RVM_RV32P_Cache_Maint(rvm_cid_t Cap_Kfn,
                                           rvm_ptr_t Cache_ID,
                                           rvm_ptr_t Operation,
                                           rvm_ptr_t Param);
RVM_EXTERN rvm_ret_t RVM_RV32P_Prfth_Mod(rvm_cid_t Cap_Kfn,
                                         rvm_ptr_t Prfth_ID,
                                         rvm_ptr_t Operation,
                                         rvm_ptr_t Param);
RVM_EXTERN rvm_ret_t RVM_RV32P_Perf_CPU_Func(rvm_cid_t Cap_Kfn,
                                         rvm_ptr_t Freg_ID,
                                         rvm_ptr_t* Content);
RVM_EXTERN rvm_ret_t RVM_RV32P_Perf_Mon_Mod(rvm_cid_t Cap_Kfn,
                                            rvm_ptr_t Perf_ID,
                                            rvm_ptr_t Operation,
                                            rvm_ptr_t Param);
RVM_EXTERN rvm_ret_t RVM_RV32P_Perf_Cycle_Mod(rvm_cid_t Cap_Kfn,
                                              rvm_ptr_t Cycle_ID, 
                                              rvm_ptr_t Operation,
                                              rvm_ptr_t Value,
                                              rvm_ptr_t* Content);
RVM_EXTERN rvm_ret_t RVM_RV32P_Debug_Print(rvm_cid_t Cap_Kfn,
                                           char Char);
RVM_EXTERN rvm_ret_t RVM_RV32P_Debug_Reg_Mod(rvm_cid_t Cap_Kfn,
                                             rvm_cid_t Cap_Thd, 
                                             rvm_ptr_t Operation,
                                             rvm_ptr_t Value,
                                             rvm_ptr_t* Content);
RVM_EXTERN rvm_ret_t RVM_RV32P_Debug_Inv_Mod(rvm_cid_t Cap_Kfn,
                                             rvm_cid_t Cap_Thd, 
                                             rvm_ptr_t Layer,
                                             rvm_ptr_t Operation,
                                             rvm_ptr_t Value,
                                             rvm_ptr_t* Content);
RVM_EXTERN rvm_ret_t RVM_RV32P_Debug_Exc_Get(rvm_cid_t Cap_Kfn,
                                             rvm_cid_t Cap_Thd,
                                             rvm_ptr_t Operation,
                                             rvm_ptr_t* Content);
/*****************************************************************************/
#endif /* __RVM_GUEST_RV32P__ */
/* End Public Function *******************************************************/

/* End Of File ***************************************************************/

/* Copyright (C) Evo-Devo Instrum. All rights reserved ***********************/

